<div align=center>
 
# 🚀 ZxCDDoS: Release v1.1 - Free DDoS Panel 🚀

<p>
 <img src="https://img.shields.io/github/stars/hoaan1995/ZxCDDoS?color=%23DF0067&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/forks/hoaan1995/ZxCDDoS?color=%239999FF&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/license/hoaan1995/ZxCDDoS?color=%23E8E8E8&style=for-the-badge"/> &nbsp;
 
</p>

> Terminal only accepts ANSI color.<br>
> Username: admin<br>
> Password: admin<br>

## Language</br>

 <img src="https://img.shields.io/badge/Python-FFDD00?style=for-the-badge&logo=python&logoColor=blue"/> <img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E"/> <img src="https://img.shields.io/badge/Perl-39457E?style=for-the-badge&logo=perl&logoColor=white"/> <img src="https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white"/> <img src="https://img.shields.io/badge/Go-00ADD8?style=for-the-badge&logo=go&logoColor=white"/>
 </div>
 
 ## Logs</br>
 - UPDATE HYPER METHOD!
 
## Screenshot
![lk](https://i.ibb.co/LNkqyPR/bandicam-2022-04-12-22-11-34-101.jpg)

# Tree
* [Read now pls](#README)
* [Info](#Info)
* [Setup](#Setup)
* [Credits](#Credits)
* [T.O.S](#TOS)
* [Contact](#Contact)

# README ♥️
Thank you for using, please help me press a star button, thank you very much.<br>
One star = continuously updating multiple methods

# Info
- [x] Open Source
- [x] Powerful
- [x] Simple
- [x] Methods for Layer 4 and 7
- [x] Bypass (Cloudflare, OVH, NFO,...)  


# Setup
```sh
CentOS:
yum install git -y
yum install golang -y
yum install perl -y
yum install python2 -y
yum install python3 -y
yum install python3-pip -y
yum install nodejs -y
yum install npm -y

Debain, Ubuntu:
apt-get install git -y
apt-get install golang -y
apt-get install perl -y
apt-get install python3 -y
apt-get install python2 -y
apt-get install python3-pip -y
apt-get install nodejs -y
apt-get install npm -y

How to use: 
- Recommended in shell of google, azure,...
- Using vps with high speed will be stronger

git clone https://github.com/hoaan1995/ZxCDDoS/
cd ZxCDDos/
npm i requests
npm i https-proxy-agent
npm i crypto-random-string
npm i events
npm i fs
npm i net
npm i cloudscraper
npm i request
npm i hcaptcha-solver
npm i randomstring
npm i cluster
npm i cloudflare-bypasser
pip3 install -r requirements.txt
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
apt-get install ./google-chrome-stable_current_amd64.deb
ulimit -n 999999
chmod 777 *
python3 c2.py
```

# Credits
```sh
zxcr9999 (Reworked CnC and added some methods .-.)
Egida (Example Panel <3)
Empfaked (Layer 7 methods <3)
HyukIsBack (Layer 7 methods <3)
im-federal (Layer 4 and AMP methods <3)
R00tS3C (Layer 4 and AMP methods <3)
TheSpeedX (HTTP, SOCKS5, SOCK4 proxies <3)
```

# TOS:
```sh
Do not attack government pages (.gov/.gob), educational pages (.edu) or the United States Department of Defense (.mil), 
the creator is not responsible for the damage caused by the attacks. 
remember: you are responsible for the attacks since this tool was created for educational purposes
```

# CONTACT:
```sh
Telegram: @zxcr9999
Discord: zxcr9999#1770
```
